/**
 * This is an interface to associate with things which the Herbivore can eat so
 * it knows
 */
public interface CarnivoreEdible {

}
