public class Main {

	/** 
	 * creates a game object and calls a play function 
	 * */
	public static void main(String[] args) {
		Game gameOfLife = new Game();
		gameOfLife.play(); 
	}
}
