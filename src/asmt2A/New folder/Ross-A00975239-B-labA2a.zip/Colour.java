public enum Colour {
	
	GREEN, YELLOW, RED, BLUE, SIENNA;
	
}
