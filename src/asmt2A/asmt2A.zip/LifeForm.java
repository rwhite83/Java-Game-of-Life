package asmt2A;

public abstract class LifeForm {
	
	/** abstract class with empty body methods to be defined by children */
	
	/**
	 * temporary method definition for testing only
	 */
	public void live() {
		System.out.println("hi");
	}
	
	public void move () {
		
	}
	
	public void spawn () {
		
	}
	
	public void die() {
		
	}
}
