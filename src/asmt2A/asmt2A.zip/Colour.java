package asmt2A;

public enum Colour {
	
	GREEN, YELLOW, SIENNA;
	
}
